#!/bin/bash
# To run this on a timer make sure you have
# 1. Bash terminal
# 2. Curl and Crontab installed
# 3. Run `crontab -e` to initalize a timed execution of this script
# 4. Type `* 3 * * * apiScraper.sh coinmarketcap` and save cron job
# 5. Make sure cron job is listed by running `crontab -l <user>`
# Note: To remove all cronjobs `crontab -r <user>`


# move to working directory
cd "${0%/*}"

subreddits=( tether bitcoin ethereum litecoin bitcoincash ripple bitcoinsv ethereumclassic eos tronix );

# Get the data from each subreddit and place it in its folder
for sub in "${subreddits[@]}"; do curl -A 'random' -H "Accept: application/json" -G https://www.reddit.com/r/${sub}.json?limit=100 > ${sub}/${sub}-$(date +"%y-%m-%d-%H:%M"); done



